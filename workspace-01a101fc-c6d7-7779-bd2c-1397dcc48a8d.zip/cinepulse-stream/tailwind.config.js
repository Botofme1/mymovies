/** @type {import('tailwindcss').Config} */
export default {content:['./index.html','./src/**/*.{ts,tsx}'],theme:{extend:{fontFamily:{sans:['Inter','ui-sans-serif','system-ui']},colors:{brand:'#e50914'},boxShadow:{glow:'0 0 36px rgba(229,9,20,.3)'}}},plugins:[]};
