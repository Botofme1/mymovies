import { useEffect, useMemo, useState } from 'react';
import {
  ChevronDown,
  ExternalLink,
  Film,
  Loader2,
  Play,
  RefreshCw,
  Server,
  Tv,
  X,
} from 'lucide-react';
import type { Episode, Media, MediaDetails, Season } from '../types/media';
import { api } from '../services/api';

type EmbedServerId = 'vidsrc' | 'vidlink';
type PlayerMediaType = 'movie' | 'tv';

interface VideoPlayerModalProps {
  media: Media;
  onClose: () => void;
}

interface EmbedServer {
  id: EmbedServerId;
  name: string;
  description: string;
  createUrl: (
    tmdbId: number,
    mediaType: PlayerMediaType,
    seasonNumber: number,
    episodeNumber: number,
  ) => string;
}

const EMBED_SERVERS: EmbedServer[] = [
  {
    id: 'vidsrc',
    name: 'VidSrc CC',
    description: 'Arabic CC',
    createUrl: (tmdbId, mediaType, seasonNumber, episodeNumber) =>
      mediaType === 'movie'
        ? `https://vidsrc.cc/v2/embed/movie/${tmdbId}`
        : `https://vidsrc.cc/v2/embed/tv/${tmdbId}/${seasonNumber}/${episodeNumber}`,
  },
  {
    id: 'vidlink',
    name: 'VidLink',
    description: 'Best subtitles',
    createUrl: (tmdbId, mediaType, seasonNumber, episodeNumber) =>
      mediaType === 'movie'
        ? `https://vidlink.pro/movie/${tmdbId}?primaryColor=b91c1c`
        : `https://vidlink.pro/tv/${tmdbId}/${seasonNumber}/${episodeNumber}?primaryColor=b91c1c`,
  },
];

export default function VideoPlayerModal({
  media,
  onClose,
}: VideoPlayerModalProps) {
  const directAnimeMedia: Media | null =
    media.mediaType === 'anime' && media.streamId
      ? {
          ...media,
          id: media.streamId,
          mediaType: media.streamType === 'movie' ? 'movie' : 'tv',
        }
      : null;

  const [playableMedia, setPlayableMedia] = useState<Media | null>(
    media.mediaType === 'anime' ? directAnimeMedia : media,
  );
  const [isResolvingAnime, setIsResolvingAnime] = useState(
    media.mediaType === 'anime' && !directAnimeMedia,
  );
  const [details, setDetails] = useState<MediaDetails | null>(null);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [selectedServer, setSelectedServer] =
    useState<EmbedServerId>('vidlink');
  const [selectedSeason, setSelectedSeason] = useState<number>(1);
  const [selectedEpisode, setSelectedEpisode] = useState<number>(1);
  const [reloadKey, setReloadKey] = useState<number>(0);
  const [isPlayerLoading, setIsPlayerLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string>('');

  const playerMediaType: PlayerMediaType =
    playableMedia?.mediaType === 'tv' ? 'tv' : 'movie';

  const selectedServerConfig =
    EMBED_SERVERS.find(
      (server: EmbedServer) => server.id === selectedServer,
    ) ?? EMBED_SERVERS[2];

  const streamUrl = useMemo((): string => {
    if (!playableMedia) return '';

    return selectedServerConfig.createUrl(
      playableMedia.id,
      playerMediaType,
      selectedSeason,
      selectedEpisode,
    );
  }, [
    playableMedia,
    playerMediaType,
    selectedEpisode,
    selectedSeason,
    selectedServerConfig,
  ]);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  useEffect(() => {
    if (media.mediaType !== 'anime' || directAnimeMedia) return;

    const controller = new AbortController();
    setIsResolvingAnime(true);
    setErrorMessage('');

    api
      .resolveAnime(media.originalTitle || media.title, controller.signal)
      .then((resolvedMedia: Media | null) => {
        if (!resolvedMedia) {
          setErrorMessage(
            'This anime could not be matched with a TMDB streaming ID.',
          );
          return;
        }
        setPlayableMedia(resolvedMedia);
      })
      .catch((error: unknown) => {
        console.error('Unable to resolve anime:', error);
        setErrorMessage('Unable to resolve this anime right now.');
      })
      .finally(() => setIsResolvingAnime(false));

    return () => controller.abort();
  }, [directAnimeMedia, media]);

  useEffect(() => {
    if (!playableMedia || playableMedia.mediaType !== 'tv') {
      setDetails(null);
      setEpisodes([]);
      return;
    }

    const controller = new AbortController();
    setErrorMessage('');

    api
      .details(playableMedia.id, 'tv', controller.signal)
      .then((response: MediaDetails | null) => {
        if (!response) {
          setErrorMessage('Season information is temporarily unavailable.');
          return;
        }

        setDetails(response);
        const firstSeason: Season | undefined = response.seasonsList[0];
        setSelectedSeason(firstSeason?.seasonNumber ?? 1);
      })
      .catch((error: unknown) => {
        console.error('Unable to load TV details:', error);
        setErrorMessage('Season information is temporarily unavailable.');
      });

    return () => controller.abort();
  }, [playableMedia]);

  useEffect(() => {
    if (!playableMedia || playableMedia.mediaType !== 'tv') return;

    const controller = new AbortController();
    setEpisodes([]);
    setSelectedEpisode(1);

    api
      .episodes(playableMedia.id, selectedSeason, controller.signal)
      .then((seasonEpisodes: Episode[]) => {
        setEpisodes(seasonEpisodes);
        setSelectedEpisode(seasonEpisodes[0]?.episodeNumber ?? 1);
      })
      .catch((error: unknown) => {
        console.error('Unable to load episodes:', error);
        setErrorMessage('Episodes are temporarily unavailable.');
      });

    return () => controller.abort();
  }, [playableMedia, selectedSeason]);

  useEffect(() => {
    setIsPlayerLoading(true);
    const timeoutId = window.setTimeout(
      () => setIsPlayerLoading(false),
      10000,
    );
    return () => window.clearTimeout(timeoutId);
  }, [streamUrl, reloadKey]);

  const handleServerChange = (serverId: EmbedServerId) => {
    setSelectedServer(serverId);
    setIsPlayerLoading(true);
    setReloadKey((currentKey: number) => currentKey + 1);
  };

  const handleReload = () => {
    setIsPlayerLoading(true);
    setReloadKey((currentKey: number) => currentKey + 1);
  };

  const handleOpenExternal = () => {
    if (!streamUrl) return;
    window.open(streamUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="video-player-title"
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-0 backdrop-blur-lg sm:p-4"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="grid h-[100dvh] w-full max-w-6xl grid-rows-[auto_minmax(0,1fr)_auto] overflow-hidden bg-[#0b0f19] shadow-2xl sm:h-[94vh] sm:rounded-2xl sm:ring-1 sm:ring-white/10">
        <header className="flex items-center gap-3 border-b border-white/10 bg-[#080b12] px-4 py-3 sm:px-5">
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-red-600/15 text-red-500">
            {playerMediaType === 'tv' ? <Tv size={18} /> : <Film size={18} />}
          </div>

          <div className="min-w-0 flex-1">
            <h2
              id="video-player-title"
              className="truncate text-sm font-bold text-white sm:text-base"
            >
              {media.title}
            </h2>
            <p className="truncate text-xs text-slate-500">
              {playerMediaType === 'tv'
                ? `Season ${selectedSeason} · Episode ${selectedEpisode}`
                : 'Now streaming'}
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 text-slate-300 transition hover:bg-white/10 hover:text-white"
            aria-label="Close player"
          >
            <X size={22} />
          </button>
        </header>

        <div className="relative min-h-0 bg-black">
          {(isResolvingAnime || isPlayerLoading) && (
            <div className="absolute inset-0 z-10 grid place-items-center bg-black">
              <div className="text-center">
                <Loader2 className="mx-auto mb-3 animate-spin text-red-600" />
                <p className="text-sm text-slate-400">
                  {isResolvingAnime
                    ? 'Matching anime stream…'
                    : `Loading ${selectedServerConfig.name}…`}
                </p>
              </div>
            </div>
          )}

          {streamUrl ? (
            <iframe
              key={`${streamUrl}-${reloadKey}`}
              src={streamUrl}
              title={`${media.title} video player`}
              className="h-full w-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
              allowFullScreen
              referrerPolicy="no-referrer"
              onLoad={() => setIsPlayerLoading(false)}
            />
          ) : (
            <div className="grid h-full place-items-center px-6 text-center text-sm text-slate-400">
              {errorMessage || 'No stream is available for this title.'}
            </div>
          )}
        </div>

        <div className="max-h-[45vh] overflow-y-auto border-t border-white/10 bg-[#0b0f19] p-4">
          <div className="flex flex-wrap items-center gap-2">
            <div className="mr-1 flex items-center gap-2 text-xs font-semibold text-slate-400">
              <Server size={16} className="text-red-500" />
              Servers
            </div>

            {EMBED_SERVERS.map((server: EmbedServer) => (
              <button
                type="button"
                key={server.id}
                onClick={() => handleServerChange(server.id)}
                className={`rounded-lg border px-3 py-2 text-xs font-semibold transition ${
                  selectedServer === server.id
                    ? 'border-red-500 bg-red-600 text-white'
                    : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
                }`}
              >
                {server.name}
                <span className="ml-1 hidden font-normal opacity-70 sm:inline">
                  · {server.description}
                </span>
              </button>
            ))}

            <button
              type="button"
              onClick={handleReload}
              className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:bg-white/10"
            >
              <RefreshCw size={14} />
              Reload
            </button>

            <button
              type="button"
              onClick={handleOpenExternal}
              disabled={!streamUrl}
              className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <ExternalLink size={14} />
              Open player
            </button>
          </div>

          {errorMessage && (
            <p className="mt-3 text-xs text-amber-400">{errorMessage}</p>
          )}

          {playerMediaType === 'tv' && (
            <section className="mt-4 border-t border-white/10 pt-4">
              <div className="relative mb-3 w-full sm:w-56">
                <select
                  value={selectedSeason}
                  onChange={(event) =>
                    setSelectedSeason(Number(event.target.value))
                  }
                  className="w-full appearance-none rounded-lg border border-white/10 bg-white/5 px-3 py-2.5 pr-9 text-sm font-medium text-white outline-none focus:border-red-500"
                >
                  {(details?.seasonsList ?? []).map((season: Season) => (
                    <option
                      key={season.id}
                      value={season.seasonNumber}
                      className="bg-[#111827]"
                    >
                      {season.name || `Season ${season.seasonNumber}`}
                    </option>
                  ))}
                  {!details?.seasonsList.length && (
                    <option value={selectedSeason} className="bg-[#111827]">
                      Season {selectedSeason}
                    </option>
                  )}
                </select>
                <ChevronDown
                  size={15}
                  className="pointer-events-none absolute right-3 top-3 text-slate-400"
                />
              </div>

              <div className="grid max-h-44 grid-cols-2 gap-2 overflow-y-auto sm:grid-cols-4 md:grid-cols-6">
                {episodes.map((episode: Episode) => (
                  <button
                    type="button"
                    key={episode.id}
                    onClick={() => {
                      setSelectedEpisode(episode.episodeNumber);
                      setReloadKey((currentKey: number) => currentKey + 1);
                    }}
                    className={`rounded-lg border p-3 text-left text-xs transition ${
                      selectedEpisode === episode.episodeNumber
                        ? 'border-red-500 bg-red-600/10 text-white'
                        : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <span className="flex items-center gap-1 font-bold">
                      {selectedEpisode === episode.episodeNumber && (
                        <Play size={11} fill="currentColor" />
                      )}
                      Episode {episode.episodeNumber}
                    </span>
                    <span className="mt-1 block truncate text-slate-500">
                      {episode.name}
                    </span>
                  </button>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
