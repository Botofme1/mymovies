export type MediaType = 'movie' | 'tv' | 'anime';
export interface Media { id:number; title:string; originalTitle?:string; overview:string; posterPath:string|null; backdropPath:string|null; rating:number; releaseDate:string; mediaType:MediaType; popularity?:number; genreIds?:number[]; seasons?:number; source?:'tmdb'|'jikan'; streamId?:number; streamType?:'movie'|'tv'; }
export interface Episode { id:number; episodeNumber:number; name:string; overview:string; stillPath:string|null; airDate:string|null; runtime:number|null; }
export interface Season { id:number; seasonNumber:number; name:string; episodeCount:number; posterPath:string|null; airDate:string|null; }
export interface MediaDetails extends Media { genres:string[]; runtime:number|null; seasonsList:Season[]; status:string; }
export interface TmdbPage<T> { page:number; results:T[]; total_pages:number; total_results:number; }
export interface SearchState { query:string; results:Media[]; loading:boolean; error:string|null; }
