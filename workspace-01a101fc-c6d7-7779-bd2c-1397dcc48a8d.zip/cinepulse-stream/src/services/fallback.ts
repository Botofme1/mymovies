import type { Media } from '../types/media';
const movie=(id:number,title:string,poster:string,backdrop:string,rating:number,year:string,overview:string):Media=>({id,title,posterPath:poster,backdropPath:backdrop,rating,releaseDate:`${year}-01-01`,overview,mediaType:'movie',source:'tmdb'});
const tv=(id:number,title:string,poster:string,backdrop:string,rating:number,year:string,overview:string):Media=>({id,title,posterPath:poster,backdropPath:backdrop,rating,releaseDate:`${year}-01-01`,overview,mediaType:'tv',source:'tmdb'});
export const fallbackMovies:Media[]=[
movie(693134,'Dune: Part Two','/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg','/xOMo8BRK7PfcJv9JCnx7s5hj0PX.jpg',8.2,'2024','Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family.'),
movie(872585,'Oppenheimer','/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg','/fm6KqXpk3M2HVveHwCrBSSBaO0V.jpg',8.1,'2023','The story of J. Robert Oppenheimer and his role in the development of the atomic bomb during World War II.'),
movie(157336,'Interstellar','/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg','/xJHokMbljvjADYdit5fK5VQsXEG.jpg',8.5,'2014','Explorers travel through a wormhole in space in an attempt to ensure humanity’s survival.'),
movie(414906,'The Batman','/74xTEgt7R36Fpooo50r9T25onhq.jpg','/b0PlSFdDwbyK0cf5RxwDpaOJQvQ.jpg',7.7,'2022','Batman ventures into Gotham City’s underworld when a sadistic killer leaves behind a trail of cryptic clues.'),
movie(76600,'Avatar: The Way of Water','/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg','/s16H6tpK2utvwDtzZ8Qy4qm5Emw.jpg',7.6,'2022','The Sully family explores the regions of Pandora and fights to keep their family safe.'),
movie(361743,'Top Gun: Maverick','/62HCnUTziyWcpDaBO2i1DX17ljH.jpg','/AaV1YIdWKnjAIAOe8UUKBFm327v.jpg',8.2,'2022','Maverick confronts the ghosts of his past while leading an elite group of graduates on a dangerous mission.'),
movie(550,'Fight Club','/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg','/hZkgoQYus5vegHoetLkCJzb17zJ.jpg',8.4,'1999','An insomniac office worker and a soap maker form an underground fight club that evolves into something much more.'),
movie(155,'The Dark Knight','/qJ2tW6WMUDux911r6m7haRef0WH.jpg','/nMKdUUepR0i5zn0y1T4CsSB5chy.jpg',8.5,'2008','Batman faces a criminal mastermind whose reign of chaos pushes Gotham and its heroes to their limits.')];
export const moreMovies:Media[]=[
movie(27205,'Inception','/oYuLEt3zVCKq57qu2F8dT7NIa6f.jpg','/s3TBrRGB1iav7gFOCNx3H31MoES.jpg',8.4,'2010','A skilled extractor who steals secrets through dream-sharing technology is given a chance to erase his past.'),
movie(680,'Pulp Fiction','/d5iIlFn5s0ImszYzBPb8JPIfbXD.jpg','/suaEOtk1N1sgg2MTM7oZd2cfVp3.jpg',8.5,'1994','The lives of two mob hitmen, a boxer and a pair of diner bandits intertwine in tales of violence and redemption.'),
movie(13,'Forrest Gump','/arw2vcBveWOVZr6pxd9XTd1TdQa.jpg','/qdIMHd4sEfJSckfVJfKQvisL02a.jpg',8.5,'1994','A kind-hearted man witnesses defining historical events while pursuing the love of his life.'),
movie(238,'The Godfather','/3bhkrj58Vtu7enYsRolD1fZdja1.jpg','/tmU7GeKVybMWFButWEGl2M4GeiP.jpg',8.7,'1972','The aging patriarch of an organized crime dynasty transfers control to his reluctant son.'),
movie(496243,'Parasite','/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg','/TU9NIjwzjoKPwQHoHshkFcQUCG.jpg',8.5,'2019','A struggling family schemes its way into the home of a wealthy household with unexpected consequences.'),
movie(475557,'Joker','/udDclJoHjfjb8Ekgsd4FDteOkCU.jpg','/n6bUvigpRFqSwmPp1m2YADdbRBc.jpg',8.1,'2019','A disregarded comedian descends into madness and inspires a violent counterculture in Gotham City.'),
movie(299536,'Avengers: Infinity War','/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg','/mDfJG3LC3Dqb67AZ52x3Z0jU0uB.jpg',8.2,'2018','The Avengers unite to stop Thanos from collecting the Infinity Stones and imposing his will on reality.'),
movie(603,'The Matrix','/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg','/icmmSD4vTTDKOq2vvdulafOGw93.jpg',8.2,'1999','A hacker discovers that his world is a simulation and joins a rebellion against its controllers.')];
export const fallbackTv:Media[]=[
tv(1396,'Breaking Bad','/3xnWaLQjelJDDF7LT1WBo6f4BRe.jpg','/tsRy63Mu5cu8etL1X7ZLyf7UP1M.jpg',8.9,'2008','A chemistry teacher diagnosed with cancer turns to manufacturing methamphetamine to secure his family’s future.'),
tv(100088,'The Last of Us','/uKvVjHNqB5VmOrdxqAt2F7J78ED.jpg','/9t0tJXcOdWwwxmGTk112HGDaT0Q.jpg',8.6,'2023','A hardened survivor escorts a young girl across a post-apocalyptic America.'),
tv(94997,'House of the Dragon','/z2yahl2uefxDCl0nogcRBstwruJ.jpg','/etj8E2o0Bud0HkONVQPjyCkIvpv.jpg',8.4,'2022','The Targaryen dynasty stands at the height of its power as a succession crisis threatens the realm.'),
tv(66732,'Stranger Things','/49WJfeN0moxb9IPfGn8AIqMGskD.jpg','/56v2KjBlU4XaOv9rVYEQypROD7P.jpg',8.6,'2016','When a young boy vanishes, a small town uncovers a mystery involving secret experiments and supernatural forces.')];
export const moreTv:Media[]=[
tv(1399,'Game of Thrones','/1XS1oqL89opfnbLl8WnZY1O1uJx.jpg','/2OMB0ynKlyIenMJWI2Dy9IWT4c.jpg',8.5,'2011','Noble families battle for control of the Iron Throne while an ancient threat returns.'),
tv(71912,'The Witcher','/cZ0d3rtvXPVvuiX22sP79K3Hmjz.jpg','/foGkPxpw9h8zln81j63mix5B7m8.jpg',8.0,'2019','A mutated monster hunter struggles to find his place in a world where people often prove more wicked than beasts.'),
tv(93405,'Squid Game','/dDlEmu3EZ0Pgg93K2SVNLCjCSvE.jpg','/qw3J9cNeLioOLoR68WX7z79aCdK.jpg',7.8,'2021','Hundreds of cash-strapped players accept an invitation to compete in deadly children’s games.'),
tv(82856,'The Mandalorian','/eU1i6eHXlzMOlEq0ku1Rzq7Y4wA.jpg','/9ijMGlJKqcslswWUzTEwScm82Gs.jpg',8.4,'2019','A lone bounty hunter travels the outer reaches of the galaxy with a mysterious child.'),
tv(60059,'Better Call Saul','/fC2HDm5t0kHl7mTm7jxMR31b7by.jpg','/9faGSFi5jam6pDWGNd0p8JcJgXQ.jpg',8.7,'2015','The transformation of small-time attorney Jimmy McGill into criminal lawyer Saul Goodman.'),
tv(70523,'Dark','/apbrbWs8M9lyOpJYU5WXrpFbk1Z.jpg','/3lBDg3i6nn5R2NKFCJ6oKyUo2j5.jpg',8.4,'2017','A missing child sets four families on a frantic hunt across multiple generations and timelines.'),
tv(1402,'The Walking Dead','/n7PVu0hSz2sAsVekpOIoCnkWlbn.jpg','/x4salpjB11umlUOltfNvSSrjSXm.jpg',8.1,'2010','Survivors search for safety and humanity in a world overrun by the undead.'),
tv(76479,'The Boys','/2zmTngn1tYC1AvfnrFLhxeD82hz.jpg','/7cqKGQMnNabzOpi7qaIgZvQ7NGV.jpg',8.5,'2019','A group of vigilantes sets out to take down corrupt superheroes who abuse their powers.')];
const anime=(id:number,title:string,poster:string,rating:number,year:string,overview:string):Media=>({id,title,posterPath:poster,backdropPath:poster,rating,releaseDate:`${year}-01-01`,overview,mediaType:'anime',source:'tmdb',streamId:id,streamType:'tv'});
export const fallbackAnime:Media[]=[
anime(37854,'One Piece','/cMD9Ygz11zjJzAovURpO75Qg7rT.jpg',8.7,'1999','Monkey D. Luffy and his pirate crew explore a fantastic world in search of the legendary treasure One Piece.'),
anime(46260,'Naruto','/vauCEnR7CiyBDzRCeElKkCaXIYu.jpg',8.4,'2002','A spirited young ninja seeks recognition and dreams of becoming the leader of his village.'),
anime(1429,'Attack on Titan','/hTP1DtLGFamjfu8WqjnuQdP1n4i.jpg',8.7,'2013','Humanity fights for survival against terrifying giants beyond its walled cities.'),
anime(85937,'Demon Slayer','/xUfRZu2mi8jH6SzQEJGP6tjBuYj.jpg',8.7,'2019','A young swordsman joins the Demon Slayer Corps after demons attack his family.'),
anime(13916,'Death Note','/iigTJJskR1PcjjXqxdyJwW3G1O.jpg',8.6,'2006','A brilliant student discovers a notebook that grants the power to kill anyone whose name is written inside.'),
anime(95479,'Jujutsu Kaisen','/fHpKWq9ayzSk8nSwqRuaAUemRKh.jpg',8.6,'2020','A student enters a secret world of sorcerers after swallowing a powerful cursed object.'),
anime(114410,'Chainsaw Man','/npdB6eFzizki0WaZ1OvKcJrWe97.jpg',8.5,'2022','A young devil hunter merges with his chainsaw devil and gains extraordinary powers.'),
anime(120089,'SPY x FAMILY','/3r4LYFuXrg3G8fepysr4xSLWnQL.jpg',8.6,'2022','A spy creates a fake family, unaware that his wife is an assassin and his daughter can read minds.')];
export const allFallbackMovies=[...fallbackMovies,...moreMovies];export const allFallbackTv=[...fallbackTv,...moreTv];
export const fallbackCatalog=[...allFallbackMovies,...allFallbackTv,...fallbackAnime];
