import type {
  Episode,
  Media,
  MediaDetails,
  MediaType,
  TmdbPage,
} from '../types/media';

const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_IMAGE_BASE_URL = 'https://image.tmdb.org/t/p';

const readToken = import.meta.env.VITE_TMDB_READ_TOKEN;
const apiKey = import.meta.env.VITE_TMDB_API_KEY;

export const hasTmdbCredentials = Boolean(readToken || apiKey);

export const imageUrl = (path: string | null, size = 'w500'): string =>
  path ? `${TMDB_IMAGE_BASE_URL}/${size}${path}` : '';

interface TmdbMediaRaw {
  id: number;
  title?: string;
  name?: string;
  original_title?: string;
  original_name?: string;
  overview?: string;
  poster_path?: string | null;
  backdrop_path?: string | null;
  vote_average?: number;
  release_date?: string;
  first_air_date?: string;
  media_type?: string;
  popularity?: number;
  genre_ids?: number[];
}

interface TmdbDetailsRaw extends TmdbMediaRaw {
  genres?: Array<{ id: number; name: string }>;
  runtime?: number | null;
  episode_run_time?: number[];
  status?: string;
  seasons?: Array<{
    id: number;
    season_number: number;
    name: string;
    episode_count: number;
    poster_path: string | null;
    air_date: string | null;
  }>;
}

interface TmdbSeasonResponse {
  episodes?: Array<{
    id: number;
    episode_number: number;
    name: string;
    overview?: string;
    still_path: string | null;
    air_date: string | null;
    runtime: number | null;
  }>;
}

interface JikanAnime {
  mal_id: number;
  title_english: string | null;
  title: string;
  synopsis: string | null;
  score: number | null;
  year: number | null;
  aired: { from: string | null };
  images: { jpg: { large_image_url: string | null } };
  trailer: { images: { maximum_image_url: string | null } };
  popularity: number;
}

interface JikanResponse {
  data?: JikanAnime[];
}

function buildTmdbUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const url = new URL(`${TMDB_BASE_URL}${normalizedPath}`);

  // The Bearer token is preferred. A v3 API key is used only when the
  // Read Access Token is not available.
  if (!readToken && apiKey) {
    url.searchParams.set('api_key', apiKey);
  }

  return url.toString();
}

async function fetchTmdb<T>(path: string, signal?: AbortSignal): Promise<T | null> {
  try {
    const response = await fetch(buildTmdbUrl(path), {
      method: 'GET',
      signal,
      headers: {
        accept: 'application/json',
        ...(readToken
          ? { Authorization: `Bearer ${import.meta.env.VITE_TMDB_READ_TOKEN}` }
          : {}),
      },
    });

    if (!response.ok) {
      const responseBody = await response.text().catch(() => '');
      throw new Error(
        `TMDB request failed: ${response.status} ${response.statusText} ` +
          `(${path})${responseBody ? ` — ${responseBody}` : ''}`,
      );
    }

    return (await response.json()) as T;
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') {
      console.error(`TMDB request aborted (${path}):`, error);
    } else {
      console.error(`TMDB fetch error (${path}):`, error);
    }
    return null;
  }
}

function normalizeMedia(item: TmdbMediaRaw, fallbackType: MediaType): Media {
  const resolvedType: MediaType =
    item.media_type === 'tv'
      ? 'tv'
      : item.media_type === 'movie'
        ? 'movie'
        : fallbackType;

  return {
    id: item.id,
    title: item.title || item.name || 'Untitled',
    originalTitle: item.original_title || item.original_name,
    overview: item.overview || 'No synopsis is available yet.',
    posterPath: item.poster_path ?? null,
    backdropPath: item.backdrop_path ?? null,
    rating: item.vote_average ?? 0,
    releaseDate: item.release_date || item.first_air_date || '',
    mediaType: resolvedType,
    popularity: item.popularity,
    genreIds: item.genre_ids,
    source: 'tmdb',
  };
}

async function fetchMediaPage(
  path: string,
  fallbackType: MediaType,
  signal?: AbortSignal,
): Promise<Media[]> {
  try {
    const response = await fetchTmdb<TmdbPage<TmdbMediaRaw>>(path, signal);
    if (!response || !Array.isArray(response.results)) return [];

    return response.results
      .filter((item) => item.media_type !== 'person')
      .map((item) => normalizeMedia(item, fallbackType));
  } catch (error) {
    console.error(`Failed to process TMDB media page (${path}):`, error);
    return [];
  }
}

export const api = {
  trending: (signal?: AbortSignal): Promise<Media[]> =>
    fetchMediaPage('/trending/all/week?language=en-US', 'movie', signal),

  popularMovies: (signal?: AbortSignal): Promise<Media[]> =>
    fetchMediaPage('/movie/popular?language=en-US', 'movie', signal),

  topRated: (signal?: AbortSignal): Promise<Media[]> =>
    fetchMediaPage('/movie/top_rated?language=en-US', 'movie', signal),

  popularTv: (signal?: AbortSignal): Promise<Media[]> =>
    fetchMediaPage('/tv/popular?language=en-US', 'tv', signal),

  search: (query: string, signal?: AbortSignal): Promise<Media[]> => {
    const trimmedQuery = query.trim();
    if (!trimmedQuery) return Promise.resolve([]);

    return fetchMediaPage(
      `/search/multi?language=en-US&include_adult=false&query=${encodeURIComponent(trimmedQuery)}`,
      'movie',
      signal,
    );
  },

  similar: (
    id: number,
    type: Exclude<MediaType, 'anime'>,
    signal?: AbortSignal,
  ): Promise<Media[]> =>
    fetchMediaPage(`/${type}/${id}/similar?language=en-US`, type, signal),

  details: async (
    id: number,
    type: Exclude<MediaType, 'anime'>,
    signal?: AbortSignal,
  ): Promise<MediaDetails | null> => {
    try {
      const details = await fetchTmdb<TmdbDetailsRaw>(
        `/${type}/${id}?language=en-US`,
        signal,
      );

      if (!details) return null;

      return {
        ...normalizeMedia(details, type),
        genres: (details.genres ?? []).map((genre) => genre.name),
        runtime:
          details.runtime ?? details.episode_run_time?.[0] ?? null,
        status: details.status ?? '',
        seasonsList: (details.seasons ?? [])
          .filter((season) => season.season_number > 0)
          .map((season) => ({
            id: season.id,
            seasonNumber: season.season_number,
            name: season.name,
            episodeCount: season.episode_count,
            posterPath: season.poster_path,
            airDate: season.air_date,
          })),
      };
    } catch (error) {
      console.error(`Failed to process TMDB details (${type}/${id}):`, error);
      return null;
    }
  },

  episodes: async (
    id: number,
    season: number,
    signal?: AbortSignal,
  ): Promise<Episode[]> => {
    const path = `/tv/${id}/season/${season}?language=en-US`;

    try {
      const response = await fetchTmdb<TmdbSeasonResponse>(path, signal);
      if (!response || !Array.isArray(response.episodes)) return [];

      return response.episodes.map((episode) => ({
        id: episode.id,
        episodeNumber: episode.episode_number,
        name: episode.name,
        overview: episode.overview ?? '',
        stillPath: episode.still_path,
        airDate: episode.air_date,
        runtime: episode.runtime,
      }));
    } catch (error) {
      console.error(`Failed to process TMDB episodes (tv/${id}/season/${season}):`, error);
      return [];
    }
  },

  resolveAnime: async (
    title: string,
    signal?: AbortSignal,
  ): Promise<Media | null> => {
    try {
      const results = await fetchMediaPage(
        `/search/tv?language=en-US&include_adult=false&query=${encodeURIComponent(title.trim())}`,
        'tv',
        signal,
      );
      return results[0] ?? null;
    } catch (error) {
      console.error(`Failed to resolve anime on TMDB (${title}):`, error);
      return null;
    }
  },
};

export async function fetchTopAnime(signal?: AbortSignal): Promise<Media[]> {
  const endpoint = 'https://api.jikan.moe/v4/top/anime?filter=bypopularity&limit=20';

  try {
    const response = await fetch(endpoint, {
      method: 'GET',
      signal,
      headers: {
        accept: 'application/json',
      },
    });

    if (!response.ok) {
      const responseBody = await response.text().catch(() => '');
      throw new Error(
        `Jikan request failed: ${response.status} ${response.statusText}` +
          `${responseBody ? ` — ${responseBody}` : ''}`,
      );
    }

    const payload = (await response.json()) as JikanResponse;
    if (!Array.isArray(payload.data)) return [];

    return payload.data.map((anime) => ({
      id: anime.mal_id,
      title: anime.title_english || anime.title,
      originalTitle: anime.title,
      overview: anime.synopsis || 'No synopsis is available yet.',
      posterPath: anime.images.jpg.large_image_url,
      backdropPath: anime.trailer.images.maximum_image_url,
      rating: anime.score ?? 0,
      releaseDate: anime.aired.from || String(anime.year ?? ''),
      mediaType: 'anime',
      popularity: anime.popularity,
      source: 'jikan',
    }));
  } catch (error) {
    console.error(`Jikan fetch error (${endpoint}):`, error);
    return [];
  }
}
